# Facial-Attendence-system
pre-requisites modules
  CV2
  NUMPY
  Facial_recogition
  CSV
  datetime
